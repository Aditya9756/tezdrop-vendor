class VendorProductModel {
  final String id;
  final String name;
  final String image;
  final double price;
  final double oldPrice;
  final String category;
  final String type;
  final String desc;
  final int stock;
  final bool isActive;
  final bool isGrocery;
  final List<Map<String, dynamic>> addOns;
  final String firebaseKey;

  const VendorProductModel({
    required this.id,
    required this.name,
    this.image     = '🍔',
    required this.price,
    this.oldPrice  = 0,
    required this.category,
    this.type      = 'veg',
    this.desc      = '',
    this.stock     = 99,
    this.isActive  = true,
    this.isGrocery = false,
    this.addOns    = const [],
    this.firebaseKey = '',
  });

  factory VendorProductModel.fromJson(Map<String, dynamic> json, {String key = ''}) => VendorProductModel(
    id          : json['id']?.toString()           ?? key,
    name        : json['name']                      ?? '',
    image       : json['image']                     ?? '🍔',
    price       : (json['price'] as num?)?.toDouble()    ?? 0,
    oldPrice    : (json['oldPrice'] as num?)?.toDouble() ?? 0,
    category    : json['category']                  ?? '',
    type        : json['type']                      ?? 'veg',
    desc        : json['desc']                      ?? '',
    stock       : (json['stock'] as num?)?.toInt()  ?? 99,
    isActive    : json['isActive']                  ?? true,
    isGrocery   : json['isGrocery']                 ?? false,
    addOns      : (json['addOns'] as List?)
        ?.whereType<Map>()
        .map((e) => {'name': e['name']?.toString() ?? '', 'price': (e['price'] as num?)?.toDouble() ?? 0.0})
        .toList() ?? [],
    firebaseKey : key,
  );

  Map<String, dynamic> toJson() => {
    'id'       : id,
    'name'     : name,
    'image'    : image,
    'price'    : price,
    'oldPrice' : oldPrice,
    'category' : category,
    'type'     : type,
    'desc'     : desc,
    'stock'    : stock,
    'isActive' : isActive,
    'isGrocery': isGrocery,
    if (addOns.isNotEmpty) 'addOns': addOns,
  };

  int get discountPercent {
    if (oldPrice <= 0 || oldPrice <= price) return 0;
    return ((1 - price / oldPrice) * 100).round();
  }
}
