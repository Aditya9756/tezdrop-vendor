class VendorOrderModel {
  final String orderId;
  final String phone;
  final String customerName;
  final String address;
  final List<Map<String, dynamic>> items;
  final double total;
  final String status;
  final String payment;
  final DateTime createdAt;
  final String firebaseKey;

  const VendorOrderModel({
    required this.orderId,
    required this.phone,
    this.customerName = '',
    this.address = '',
    required this.items,
    required this.total,
    this.status = 'Pending',
    this.payment = 'COD',
    required this.createdAt,
    this.firebaseKey = '',
  });

  factory VendorOrderModel.fromJson(Map<String, dynamic> json, {String key = ''}) => VendorOrderModel(
    orderId      : json['orderId']?.toString()      ?? '',
    phone        : json['phone']                     ?? '',
    customerName : json['customerName']              ?? 'Customer',
    address      : json['address']?.toString()       ?? '',
    items        : (json['items'] as List?)
        ?.whereType<Map>()
        .map((e) => Map<String, dynamic>.from(e))
        .toList() ?? [],
    total        : (json['total'] as num?)?.toDouble() ?? 0,
    status       : json['status']                    ?? 'Pending',
    payment      : json['payment']                   ?? 'COD',
    createdAt    : DateTime.tryParse(json['createdAt']?.toString() ?? '') ?? DateTime.now(),
    firebaseKey  : key,
  );

  String get timeAgo {
    final diff = DateTime.now().difference(createdAt);
    if (diff.inMinutes < 1) return 'Just now';
    if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
    if (diff.inHours < 24) return '${diff.inHours}h ago';
    return '${diff.inDays}d ago';
  }

  bool get canCancel => status == 'Pending' || status == 'Confirmed';
  bool get isPending => status == 'Pending';
  bool get isPreparing => status == 'Preparing';
  bool get isReady => status == 'Ready';
  bool get isDelivered => status == 'Delivered';
  bool get isCancelled => status == 'Cancelled';
}
