class VendorModel {
  final String id;
  final String phone;
  final String name;
  final String shopName;
  final String category;
  final String address;
  final String openTime;
  final String closeTime;
  final bool isOpen;
  final double rating;
  final int totalOrders;
  final double totalEarnings;
  final String firebaseKey;

  const VendorModel({
    required this.id,
    required this.phone,
    this.name = '',
    this.shopName = '',
    this.category = 'Food',
    this.address = '',
    this.openTime = '9:00 AM',
    this.closeTime = '11:00 PM',
    this.isOpen = true,
    this.rating = 0.0,
    this.totalOrders = 0,
    this.totalEarnings = 0.0,
    this.firebaseKey = '',
  });

  factory VendorModel.fromJson(Map<String, dynamic> json) => VendorModel(
    id            : json['id']?.toString()           ?? '',
    phone         : json['phone']                     ?? '',
    name          : json['name']                      ?? '',
    shopName      : json['shopName']                  ?? '',
    category      : json['category']                  ?? 'Food',
    address       : json['address']                   ?? '',
    openTime      : json['openTime']                  ?? '9:00 AM',
    closeTime     : json['closeTime']                 ?? '11:00 PM',
    isOpen        : json['isOpen']                    ?? true,
    rating        : (json['rating'] as num?)?.toDouble()        ?? 0.0,
    totalOrders   : (json['totalOrders'] as num?)?.toInt()      ?? 0,
    totalEarnings : (json['totalEarnings'] as num?)?.toDouble() ?? 0.0,
    firebaseKey   : json['firebaseKey']               ?? '',
  );

  Map<String, dynamic> toJson() => {
    'id'            : id,
    'phone'         : phone,
    'name'          : name,
    'shopName'      : shopName,
    'category'      : category,
    'address'       : address,
    'openTime'      : openTime,
    'closeTime'     : closeTime,
    'isOpen'        : isOpen,
    'rating'        : rating,
    'totalOrders'   : totalOrders,
    'totalEarnings' : totalEarnings,
  };

  VendorModel copyWith({
    String? shopName, String? category, String? address,
    String? openTime, String? closeTime, bool? isOpen,
    double? rating, int? totalOrders, double? totalEarnings,
  }) => VendorModel(
    id            : id,
    phone         : phone,
    name          : name,
    shopName      : shopName      ?? this.shopName,
    category      : category      ?? this.category,
    address       : address       ?? this.address,
    openTime      : openTime      ?? this.openTime,
    closeTime     : closeTime     ?? this.closeTime,
    isOpen        : isOpen        ?? this.isOpen,
    rating        : rating        ?? this.rating,
    totalOrders   : totalOrders   ?? this.totalOrders,
    totalEarnings : totalEarnings ?? this.totalEarnings,
    firebaseKey   : firebaseKey,
  );
}
