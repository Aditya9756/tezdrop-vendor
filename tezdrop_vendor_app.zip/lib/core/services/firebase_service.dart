import 'dart:convert';
import 'package:http/http.dart' as http;
import '../constants/app_strings.dart';
import '../models/vendor_model.dart';
import '../models/product_model.dart';
import '../models/order_model.dart';

class VendorFirebaseService {
  static final String _base = AppStrings.firebaseUrl;

  // ── VENDOR ──────────────────────────────
  static Future<VendorModel?> getVendor(String phone) async {
    try {
      final res = await http.get(
        Uri.parse('$_base/vendors.json?orderBy="phone"&equalTo="$phone"'),
      ).timeout(const Duration(seconds: 8));
      if (res.statusCode != 200) return null;
      final data = json.decode(res.body) as Map<String, dynamic>?;
      if (data == null || data.isEmpty) return null;
      final key = data.keys.first;
      return VendorModel.fromJson({...Map<String, dynamic>.from(data[key]), 'firebaseKey': key});
    } catch (_) { return null; }
  }

  static Future<bool> saveVendor(VendorModel vendor) async {
    try {
      final key = vendor.firebaseKey.isNotEmpty ? vendor.firebaseKey : vendor.phone.replaceAll('+', '').replaceAll(' ', '');
      final res = await http.put(
        Uri.parse('$_base/vendors/$key.json'),
        body: json.encode(vendor.toJson()),
      ).timeout(const Duration(seconds: 8));
      return res.statusCode == 200;
    } catch (_) { return false; }
  }

  static Future<bool> updateVendorOpen(String firebaseKey, bool isOpen) async {
    try {
      final res = await http.patch(
        Uri.parse('$_base/vendors/$firebaseKey.json'),
        body: json.encode({'isOpen': isOpen}),
      ).timeout(const Duration(seconds: 8));
      return res.statusCode == 200;
    } catch (_) { return false; }
  }

  // ── PRODUCTS ──────────────────────────────
  static Future<List<VendorProductModel>> getProducts(String vendorId) async {
    try {
      final res = await http.get(
        Uri.parse('$_base/products.json?orderBy="restId"&equalTo="$vendorId"'),
      ).timeout(const Duration(seconds: 8));
      if (res.statusCode != 200) return [];
      final data = json.decode(res.body) as Map<String, dynamic>?;
      if (data == null) return [];
      return data.entries
          .map((e) => VendorProductModel.fromJson(Map<String, dynamic>.from(e.value), key: e.key))
          .toList();
    } catch (_) { return []; }
  }

  static Future<String?> saveProduct(VendorProductModel p) async {
    try {
      if (p.firebaseKey.isNotEmpty) {
        await http.put(
          Uri.parse('$_base/products/${p.firebaseKey}.json'),
          body: json.encode(p.toJson()),
        ).timeout(const Duration(seconds: 8));
        return p.firebaseKey;
      } else {
        final res = await http.post(
          Uri.parse('$_base/products.json'),
          body: json.encode(p.toJson()),
        ).timeout(const Duration(seconds: 8));
        final data = json.decode(res.body);
        return data['name']?.toString();
      }
    } catch (_) { return null; }
  }

  static Future<bool> deleteProduct(String firebaseKey) async {
    try {
      final res = await http.delete(
        Uri.parse('$_base/products/$firebaseKey.json'),
      ).timeout(const Duration(seconds: 8));
      return res.statusCode == 200;
    } catch (_) { return false; }
  }

  static Future<bool> updateProductStock(String firebaseKey, int stock, bool isActive) async {
    try {
      final res = await http.patch(
        Uri.parse('$_base/products/$firebaseKey.json'),
        body: json.encode({'stock': stock, 'isActive': isActive}),
      ).timeout(const Duration(seconds: 8));
      return res.statusCode == 200;
    } catch (_) { return false; }
  }

  // ── ORDERS ──────────────────────────────
  static Future<List<VendorOrderModel>> getOrders(String vendorId) async {
    try {
      final res = await http.get(
        Uri.parse('$_base/orders.json'),
      ).timeout(const Duration(seconds: 10));
      if (res.statusCode != 200) return [];
      final data = json.decode(res.body) as Map<String, dynamic>?;
      if (data == null) return [];

      final List<VendorOrderModel> orders = [];
      data.forEach((phone, phoneOrders) {
        if (phoneOrders is Map) {
          phoneOrders.forEach((key, orderData) {
            if (orderData is Map) {
              final o = VendorOrderModel.fromJson(
                Map<String, dynamic>.from(orderData), key: key);
              orders.add(o);
            }
          });
        }
      });

      orders.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      return orders;
    } catch (_) { return []; }
  }

  static Future<bool> updateOrderStatus(String phone, String firebaseKey, String status) async {
    try {
      final cleanPhone = phone.replaceAll('+', '').replaceAll(' ', '');
      final res = await http.patch(
        Uri.parse('$_base/orders/$cleanPhone/$firebaseKey.json'),
        body: json.encode({'status': status}),
      ).timeout(const Duration(seconds: 8));
      return res.statusCode == 200;
    } catch (_) { return false; }
  }
}
