class AppStrings {
  static const String appName = 'TezDrop Vendor';
  
  // Same Firebase as customer app
  static const String firebaseUrl = 
      String.fromEnvironment('FB_URL', 
        defaultValue: 'https://tezdrop-84fb4-default-rtdb.firebaseio.com');
  
  static const String otpApiKey = 
      String.fromEnvironment('OTP_KEY',
        defaultValue: '6dda5f99-5a4a-11f1-8352-0200cd936042');
  
  static const String supportPhone = '+919756765881';
  static const String supportWhatsApp = 'https://wa.me/919756765881';
}
