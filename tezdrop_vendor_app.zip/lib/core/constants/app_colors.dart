import 'package:flutter/material.dart';

class AppColors {
  static const Color primary    = Color(0xFFEF4444);
  static const Color secondary  = Color(0xFFFF6B35);
  static const Color orange     = Color(0xFFF97316);
  static const Color green      = Color(0xFF22C55E);
  static const Color yellow     = Color(0xFFF59E0B);
  static const Color blue       = Color(0xFF3B82F6);
  static const Color dark       = Color(0xFF111827);
  static const Color textGrey   = Color(0xFF6B7280);
  static const Color textLight  = Color(0xFF9CA3AF);
  static const Color border     = Color(0xFFE5E7EB);
  static const Color bg         = Color(0xFFF3F4F6);
  static const Color surface    = Color(0xFFFFFFFF);

  static const LinearGradient brandGradient = LinearGradient(
    colors: [Color(0xFFEF4444), Color(0xFFFF6B35)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient darkGradient = LinearGradient(
    colors: [Color(0xFF1F2937), Color(0xFF111827)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}
