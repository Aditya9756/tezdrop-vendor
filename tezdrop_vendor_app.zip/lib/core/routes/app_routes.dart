import 'package:flutter/material.dart';
import '../../views/onboarding/splash_screen.dart';
import '../../views/onboarding/login_screen.dart';
import '../../views/onboarding/otp_screen.dart';
import '../../views/dashboard/dashboard_screen.dart';
import '../../views/products/add_product_screen.dart';
import '../../views/profile/edit_profile_screen.dart';

class AppRoutes {
  static const splash      = '/';
  static const login       = '/login';
  static const otp         = '/otp';
  static const dashboard   = '/dashboard';
  static const addProduct  = '/add-product';
  static const editProfile = '/edit-profile';

  static Route<dynamic> generate(RouteSettings s) {
    final args = s.arguments as Map<String, dynamic>? ?? {};
    switch (s.name) {
      case splash:      return _fade(const SplashScreen());
      case login:       return _fade(const LoginScreen());
      case otp:         return _slide(OtpScreen(phone: args['phone'] ?? ''));
      case dashboard:   return _fade(const DashboardScreen());
      case addProduct:  return _slide(AddProductScreen(product: args['product']));
      case editProfile: return _slide(const EditProfileScreen());
      default:          return _fade(const SplashScreen());
    }
  }

  static PageRoute _fade(Widget w) => PageRouteBuilder(
    pageBuilder: (_, __, ___) => w,
    transitionsBuilder: (_, a, __, c) => FadeTransition(opacity: a, child: c),
    transitionDuration: const Duration(milliseconds: 300),
  );

  static PageRoute _slide(Widget w) => PageRouteBuilder(
    pageBuilder: (_, __, ___) => w,
    transitionsBuilder: (_, a, __, c) => SlideTransition(
      position: Tween(begin: const Offset(1, 0), end: Offset.zero).animate(
        CurvedAnimation(parent: a, curve: Curves.easeOutCubic)),
      child: c,
    ),
    transitionDuration: const Duration(milliseconds: 350),
  );
}
