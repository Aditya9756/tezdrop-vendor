import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../core/models/order_model.dart';
import '../../providers/vendor_provider.dart';
import '../orders/widgets/order_card.dart';

class HomeTab extends StatelessWidget {
  const HomeTab({super.key});

  @override
  Widget build(BuildContext context) {
    final vp = context.watch<VendorProvider>();
    final v = vp.vendor;

    return SafeArea(
      bottom: false,
      child: RefreshIndicator(
        onRefresh: vp.loadData,
        color: AppColors.primary,
        child: CustomScrollView(
          slivers: [
            // Header
            SliverToBoxAdapter(
              child: Container(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
                decoration: const BoxDecoration(gradient: AppColors.brandGradient),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(v?.shopName.isNotEmpty == true ? '🍕 ${v!.shopName}' : '🏪 Your Shop',
                        style: const TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.w900)),
                      const SizedBox(height: 2),
                      Text(v?.address.isNotEmpty == true ? v!.address : 'Set your address',
                        style: TextStyle(color: Colors.white.withValues(alpha: 0.85), fontSize: 11)),
                    ])),
                    GestureDetector(
                      onTap: () => vp.toggleShopOpen(),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                        decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.22), borderRadius: BorderRadius.circular(20)),
                        child: Row(mainAxisSize: MainAxisSize.min, children: [
                          Container(width: 8, height: 8, decoration: BoxDecoration(
                            color: (v?.isOpen ?? true) ? const Color(0xFF4ADE80) : const Color(0xFFFCA5A5), shape: BoxShape.circle)),
                          const SizedBox(width: 6),
                          Text((v?.isOpen ?? true) ? 'OPEN' : 'CLOSED',
                            style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w800)),
                        ]),
                      ),
                    ),
                  ]),
                ]),
              ),
            ),

            // Stats
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(14, 14, 14, 0),
              sliver: SliverToBoxAdapter(
                child: Row(children: [
                  Expanded(child: _StatCard(emoji: '📦', value: '${vp.todayOrders}', label: 'TODAY ORDERS')),
                  const SizedBox(width: 10),
                  Expanded(child: _StatCard(emoji: '💰', value: '₹${vp.todayEarnings.toStringAsFixed(0)}', label: 'REVENUE')),
                  const SizedBox(width: 10),
                  Expanded(child: _StatCard(emoji: '⏳', value: '${vp.pendingOrders.length}', label: 'PENDING', color: AppColors.orange)),
                ]),
              ),
            ),

            SliverToBoxAdapter(child: Padding(
              padding: const EdgeInsets.fromLTRB(18, 20, 18, 8),
              child: Row(children: const [
                Text('🔴', style: TextStyle(fontSize: 14)),
                SizedBox(width: 6),
                Text('Live Orders', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
              ]),
            )),

            if (vp.loading)
              const SliverToBoxAdapter(child: Padding(padding: EdgeInsets.all(40), child: Center(child: CircularProgressIndicator(color: AppColors.primary))))
            else if (vp.pendingOrders.isEmpty && vp.preparingOrders.isEmpty)
              SliverToBoxAdapter(child: Padding(
                padding: const EdgeInsets.all(40),
                child: Column(children: const [
                  Text('🍽️', style: TextStyle(fontSize: 48)),
                  SizedBox(height: 8),
                  Text('No live orders right now', style: TextStyle(color: AppColors.textGrey, fontWeight: FontWeight.w600)),
                ]),
              ))
            else
              SliverPadding(
                padding: const EdgeInsets.symmetric(horizontal: 14),
                sliver: SliverList(delegate: SliverChildBuilderDelegate(
                  (_, i) {
                    final list = [...vp.pendingOrders, ...vp.preparingOrders];
                    return OrderCard(order: list[i]);
                  },
                  childCount: [...vp.pendingOrders, ...vp.preparingOrders].length,
                )),
              ),

            const SliverToBoxAdapter(child: SizedBox(height: 20)),
          ],
        ),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String emoji, value, label;
  final Color? color;
  const _StatCard({required this.emoji, required this.value, required this.label, this.color});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 10, offset: const Offset(0, 3))]),
      child: Column(children: [
        Text(emoji, style: const TextStyle(fontSize: 22)),
        const SizedBox(height: 4),
        Text(value, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: color ?? const Color(0xFF111827))),
        const SizedBox(height: 2),
        Text(label, style: const TextStyle(fontSize: 8.5, fontWeight: FontWeight.w700, color: AppColors.textGrey, letterSpacing: 0.3)),
      ]),
    );
  }
}
