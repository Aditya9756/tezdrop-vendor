import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../core/routes/app_routes.dart';
import '../../providers/vendor_provider.dart';
import '../orders/orders_screen.dart';
import '../products/products_screen.dart';
import '../profile/profile_screen.dart';
import 'home_tab.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _tab = 0;
  final _screens = const [HomeTab(), OrdersScreen(), ProductsScreen(), ProfileScreen()];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<VendorProvider>().loadData();
    });
  }

  @override
  Widget build(BuildContext context) {
    final vp = context.watch<VendorProvider>();
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: IndexedStack(index: _tab, children: _screens),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(color: Colors.white, boxShadow: [
          BoxShadow(color: Colors.black.withValues(alpha: 0.07), blurRadius: 16, offset: const Offset(0, -4)),
        ]),
        child: SafeArea(
          child: SizedBox(
            height: 64,
            child: Row(children: [
              _navItem(0, Icons.home_rounded, 'Home'),
              _navItem(1, Icons.receipt_long_rounded, 'Orders', badge: vp.pendingOrders.length),
              _navItem(2, Icons.inventory_2_rounded, 'Products'),
              _navItem(3, Icons.storefront_rounded, 'Profile'),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _navItem(int i, IconData icon, String label, {int badge = 0}) {
    final active = _tab == i;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _tab = i),
        behavior: HitTestBehavior.opaque,
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Stack(clipBehavior: Clip.none, children: [
            Icon(icon, color: active ? AppColors.primary : AppColors.textLight, size: 24),
            if (badge > 0) Positioned(right: -6, top: -4, child: Container(
              padding: const EdgeInsets.all(3),
              decoration: const BoxDecoration(color: AppColors.primary, shape: BoxShape.circle),
              constraints: const BoxConstraints(minWidth: 16, minHeight: 16),
              child: Text('$badge', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w800)),
            )),
          ]),
          const SizedBox(height: 3),
          Text(label, style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: active ? AppColors.primary : AppColors.textLight)),
        ]),
      ),
    );
  }
}
