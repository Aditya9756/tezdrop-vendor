import 'dart:async';
import 'package:flutter/material.dart';
import 'package:pinput/pinput.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../core/routes/app_routes.dart';
import '../../core/services/otp_service.dart';
import '../../providers/vendor_provider.dart';

class OtpScreen extends StatefulWidget {
  final String phone;
  const OtpScreen({super.key, required this.phone});
  @override
  State<OtpScreen> createState() => _OtpScreenState();
}

class _OtpScreenState extends State<OtpScreen> with SingleTickerProviderStateMixin {
  final _otpCtrl = TextEditingController();
  bool _loading = false;
  int _timer = 30;
  Timer? _t;
  late AnimationController _animCtrl;

  @override
  void initState() {
    super.initState();
    _animCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 500))..forward();
    _startTimer();
  }

  void _startTimer() {
    _timer = 30;
    _t?.cancel();
    _t = Timer.periodic(const Duration(seconds: 1), (t) {
      if (_timer == 0) { t.cancel(); } else { setState(() => _timer--); }
    });
  }

  @override
  void dispose() { _otpCtrl.dispose(); _t?.cancel(); _animCtrl.dispose(); super.dispose(); }

  Future<void> _verify() async {
    final code = _otpCtrl.text.trim();
    if (code.length != 6) return;
    setState(() => _loading = true);
    final session = context.read<VendorProvider>().otpSession ?? '';
    final ok = await VendorOtpService.verifyOtp(session, code);
    if (!mounted) return;
    setState(() => _loading = false);
    if (ok) {
      _finishLogin();
    } else {
      _snack('Invalid OTP. Please try again.');
      _otpCtrl.clear();
    }
  }

  void _finishLogin() async {
    final vp = context.read<VendorProvider>();
    final existing = await vp.login(widget.phone);
    if (!mounted) return;
    if (existing) {
      Navigator.pushNamedAndRemoveUntil(context, AppRoutes.dashboard, (r) => false);
    } else {
      _showNameDialog();
    }
  }

  void _showNameDialog() {
    final nameCtrl = TextEditingController();
    final shopCtrl = TextEditingController();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('🏪', style: TextStyle(fontSize: 40)),
            const SizedBox(height: 8),
            const Text('Setup your shop', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
            const SizedBox(height: 4),
            const Text('Tell us about your business', style: TextStyle(color: AppColors.textGrey, fontSize: 13)),
            const SizedBox(height: 20),
            TextField(controller: nameCtrl, decoration: InputDecoration(hintText: 'Your Name', filled: true, fillColor: const Color(0xFFF9FAFB),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none))),
            const SizedBox(height: 12),
            TextField(controller: shopCtrl, decoration: InputDecoration(hintText: 'Shop Name (e.g. Pizza Hub)', filled: true, fillColor: const Color(0xFFF9FAFB),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none))),
            const SizedBox(height: 20),
            SizedBox(width: double.infinity, child: ElevatedButton(
              onPressed: () async {
                if (nameCtrl.text.trim().isEmpty || shopCtrl.text.trim().isEmpty) return;
                await context.read<VendorProvider>().createVendor('+91${widget.phone}', nameCtrl.text.trim(), shopCtrl.text.trim());
                if (mounted) Navigator.pushNamedAndRemoveUntil(context, AppRoutes.dashboard, (r) => false);
              },
              style: ElevatedButton.styleFrom(backgroundColor: AppColors.primary, padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
              child: const Text('Start Selling 🚀', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 15)),
            )),
            const SizedBox(height: 8),
          ]),
        ),
      ),
    );
  }

  Future<void> _resend() async {
    final session = await VendorOtpService.sendOtp(widget.phone);
    if (session != null) {
      context.read<VendorProvider>().setOtpSession(session);
      _snack('OTP Resent! 📲');
      _startTimer();
    } else {
      _snack('Could not resend. Try again.');
    }
  }

  void _snack(String msg) { if (!mounted) return; ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)))); }

  @override
  Widget build(BuildContext context) {
    final defaultPinTheme = PinTheme(
      width: 50, height: 56,
      textStyle: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: Color(0xFF111827)),
      decoration: BoxDecoration(color: const Color(0xFFF9FAFB), borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFFE5E7EB))),
    );

    return Scaffold(
      backgroundColor: Colors.white,
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 16),
                GestureDetector(onTap: () => Navigator.pop(context),
                  child: Container(width: 40, height: 40, decoration: BoxDecoration(color: const Color(0xFFF3F4F6), borderRadius: BorderRadius.circular(12)),
                    child: const Icon(Icons.arrow_back, size: 20))),
                const SizedBox(height: 24),
                const Text('Verify OTP', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
                const SizedBox(height: 8),
                Text.rich(TextSpan(style: const TextStyle(color: AppColors.textGrey, fontSize: 14), children: [
                  const TextSpan(text: 'Code sent to '),
                  TextSpan(text: '+91 ${widget.phone}', style: const TextStyle(fontWeight: FontWeight.w800, color: Color(0xFF111827))),
                ])),
                const SizedBox(height: 32),
                Pinput(
                  length: 6,
                  controller: _otpCtrl,
                  defaultPinTheme: defaultPinTheme,
                  focusedPinTheme: defaultPinTheme.copyDecorationWith(border: Border.all(color: AppColors.primary, width: 2)),
                  submittedPinTheme: defaultPinTheme.copyWith(decoration: defaultPinTheme.decoration!.copyWith(color: const Color(0xFFFFF1F1))),
                  onCompleted: (_) => _verify(),
                ),
                const SizedBox(height: 24),
                Center(
                  child: _timer > 0
                    ? Text('Resend OTP in ${_timer}s', style: const TextStyle(color: AppColors.textGrey, fontSize: 13))
                    : GestureDetector(onTap: _resend, child: const Text('Resend OTP', style: TextStyle(color: AppColors.primary, fontWeight: FontWeight.w800, fontSize: 13))),
                ),
                const SizedBox(height: 32),
                GestureDetector(
                  onTap: _loading ? null : _verify,
                  child: Container(
                    width: double.infinity, padding: const EdgeInsets.symmetric(vertical: 16),
                    decoration: BoxDecoration(gradient: _loading ? null : AppColors.brandGradient, color: _loading ? const Color(0xFFE5E7EB) : null,
                      borderRadius: BorderRadius.circular(16)),
                    child: Center(child: _loading
                      ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5))
                      : const Text('Verify & Continue', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 15))),
                  ),
                ),
                const SizedBox(height: 24),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
