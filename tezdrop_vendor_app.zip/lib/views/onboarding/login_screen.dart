import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../core/routes/app_routes.dart';
import '../../core/services/otp_service.dart';
import '../../providers/vendor_provider.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> with SingleTickerProviderStateMixin {
  final _phoneCtrl = TextEditingController();
  bool _loading = false;
  bool _terms = false;
  late AnimationController _animCtrl;
  late Animation<Offset> _slideAnim;

  @override
  void initState() {
    super.initState();
    _animCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _slideAnim = Tween(begin: const Offset(0, 0.3), end: Offset.zero)
        .animate(CurvedAnimation(parent: _animCtrl, curve: Curves.easeOutCubic));
    _animCtrl.forward();
  }

  @override
  void dispose() { _phoneCtrl.dispose(); _animCtrl.dispose(); super.dispose(); }

  Future<void> _sendOtp() async {
    if (_phoneCtrl.text.trim().length != 10) {
      _snack('Please enter a valid 10-digit number');
      return;
    }
    if (!_terms) { _snack('Please agree to Terms & Policy'); return; }
    setState(() => _loading = true);
    final phone = _phoneCtrl.text.trim();
    final session = await VendorOtpService.sendOtp(phone);
    setState(() => _loading = false);
    if (!mounted) return;
    if (session != null) {
      context.read<VendorProvider>().setOtpSession(session);
      Navigator.pushNamed(context, AppRoutes.otp, arguments: {'phone': phone});
    } else {
      _snack('Could not send OTP. Check network and try again.');
    }
  }

  void _snack(String msg) => ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: SlideTransition(
          position: _slideAnim,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 48),
                // Logo
                Container(
                  width: 72,
                  height: 72,
                  decoration: BoxDecoration(
                    gradient: AppColors.brandGradient,
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [BoxShadow(color: AppColors.primary.withValues(alpha: 0.3), blurRadius: 16, offset: const Offset(0, 6))],
                  ),
                  child: const Center(child: Text('🏪', style: TextStyle(fontSize: 36))),
                ),
                const SizedBox(height: 28),
                RichText(text: const TextSpan(
                  style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: Color(0xFF111827), height: 1.2),
                  children: [
                    TextSpan(text: 'Welcome to\n'),
                    TextSpan(text: 'TezDrop ', style: TextStyle(color: Color(0xFFEF4444))),
                    TextSpan(text: 'Vendor'),
                  ],
                )),
                const SizedBox(height: 8),
                const Text('Manage orders, products & earnings 🚀', style: TextStyle(color: Color(0xFF6B7280), fontSize: 14)),
                const SizedBox(height: 40),
                // Phone input
                const Text('MOBILE NUMBER', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: Color(0xFF6B7280), letterSpacing: 1)),
                const SizedBox(height: 8),
                Container(
                  decoration: BoxDecoration(
                    border: Border.all(color: const Color(0xFFE5E7EB), width: 1.5),
                    borderRadius: BorderRadius.circular(14),
                    color: const Color(0xFFF9FAFB),
                  ),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 16),
                        decoration: const BoxDecoration(
                          border: Border(right: BorderSide(color: Color(0xFFE5E7EB))),
                        ),
                        child: const Text('+91', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                      ),
                      Expanded(
                        child: TextField(
                          controller: _phoneCtrl,
                          keyboardType: TextInputType.phone,
                          maxLength: 10,
                          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, letterSpacing: 2),
                          decoration: const InputDecoration(
                            hintText: '9876543210',
                            border: InputBorder.none,
                            contentPadding: EdgeInsets.symmetric(horizontal: 14),
                            counterText: '',
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                // Terms
                GestureDetector(
                  onTap: () => setState(() => _terms = !_terms),
                  child: Row(
                    children: [
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        width: 20, height: 20,
                        decoration: BoxDecoration(
                          color: _terms ? AppColors.primary : Colors.white,
                          border: Border.all(color: _terms ? AppColors.primary : const Color(0xFFD1D5DB), width: 2),
                          borderRadius: BorderRadius.circular(5),
                        ),
                        child: _terms ? const Icon(Icons.check, color: Colors.white, size: 13) : null,
                      ),
                      const SizedBox(width: 10),
                      const Expanded(
                        child: Text.rich(TextSpan(
                          style: TextStyle(fontSize: 12, color: Color(0xFF6B7280)),
                          children: [
                            TextSpan(text: 'I agree to the '),
                            TextSpan(text: 'Vendor Terms & Policy', style: TextStyle(color: Color(0xFFEF4444), fontWeight: FontWeight.w700)),
                          ],
                        )),
                      ),
                    ],
                  ),
                ),
                const Spacer(),
                // CTA
                GestureDetector(
                  onTap: _loading ? null : _sendOtp,
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    decoration: BoxDecoration(
                      gradient: _loading ? null : AppColors.brandGradient,
                      color: _loading ? const Color(0xFFE5E7EB) : null,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: _loading ? null : [BoxShadow(color: AppColors.primary.withValues(alpha: 0.35), blurRadius: 16, offset: const Offset(0, 6))],
                    ),
                    child: Center(
                      child: _loading
                          ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5))
                          : const Row(mainAxisSize: MainAxisSize.min, children: [
                              Text('Get OTP', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w800)),
                              SizedBox(width: 8),
                              Text('→', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w800)),
                            ]),
                    ),
                  ),
                ),
                const SizedBox(height: 32),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
