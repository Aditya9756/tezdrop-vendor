import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../core/models/product_model.dart';
import '../../providers/vendor_provider.dart';

class AddProductScreen extends StatefulWidget {
  final VendorProductModel? product;
  const AddProductScreen({super.key, this.product});
  @override
  State<AddProductScreen> createState() => _AddProductScreenState();
}

class _AddProductScreenState extends State<AddProductScreen> {
  late TextEditingController _name, _price, _oldPrice, _stock, _image, _desc;
  String _category = 'Pizza';
  String _type = 'veg';
  bool _saving = false;
  List<Map<String, TextEditingController>> _addons = [];

  final _categories = ['Pizza', 'Burger', 'Biryani', 'Snacks', 'Beverages', 'Grocery', 'Desserts'];

  @override
  void initState() {
    super.initState();
    final p = widget.product;
    _name     = TextEditingController(text: p?.name ?? '');
    _price    = TextEditingController(text: p != null ? p.price.toInt().toString() : '');
    _oldPrice = TextEditingController(text: p != null && p.oldPrice > 0 ? p.oldPrice.toInt().toString() : '');
    _stock    = TextEditingController(text: p != null ? p.stock.toString() : '10');
    _image    = TextEditingController(text: p?.image ?? '🍔');
    _desc     = TextEditingController(text: p?.desc ?? '');
    _category = p?.category ?? 'Pizza';
    _type     = p?.type ?? 'veg';
    _addons   = (p?.addOns ?? []).map((a) => {
      'name': TextEditingController(text: a['name']?.toString() ?? ''),
      'price': TextEditingController(text: (a['price'] as num?)?.toInt().toString() ?? ''),
    }).toList();
  }

  void _addAddon() => setState(() => _addons.add({'name': TextEditingController(), 'price': TextEditingController()}));
  void _removeAddon(int i) => setState(() => _addons.removeAt(i));

  Future<void> _save() async {
    if (_name.text.trim().isEmpty) { _snack('Enter product name'); return; }
    if (_price.text.trim().isEmpty) { _snack('Enter price'); return; }

    setState(() => _saving = true);
    final vp = context.read<VendorProvider>();

    final addOns = _addons
        .where((a) => a['name']!.text.trim().isNotEmpty)
        .map((a) => {'name': a['name']!.text.trim(), 'price': double.tryParse(a['price']!.text) ?? 0.0})
        .toList();

    final product = VendorProductModel(
      id: widget.product?.id ?? '',
      name: _name.text.trim(),
      image: _image.text.trim().isEmpty ? '🍔' : _image.text.trim(),
      price: double.tryParse(_price.text) ?? 0,
      oldPrice: double.tryParse(_oldPrice.text) ?? 0,
      category: _category,
      type: _type,
      desc: _desc.text.trim(),
      stock: int.tryParse(_stock.text) ?? 10,
      isActive: widget.product?.isActive ?? true,
      isGrocery: _category == 'Grocery',
      addOns: addOns,
      firebaseKey: widget.product?.firebaseKey ?? '',
    );

    final ok = await vp.saveProduct(product);
    setState(() => _saving = false);
    if (!mounted) return;
    if (ok) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Product saved! ✅'), backgroundColor: AppColors.green,
        behavior: SnackBarBehavior.floating));
    } else {
      _snack('Failed to save. Check internet.');
    }
  }

  void _snack(String msg) => ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      resizeToAvoidBottomInset: true,
      body: SafeArea(
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 6),
            child: Row(children: [
              GestureDetector(onTap: () => Navigator.pop(context),
                child: Container(width: 38, height: 38, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12)),
                  child: const Icon(Icons.arrow_back, size: 19))),
              const SizedBox(width: 12),
              Text(widget.product != null ? 'Edit Product' : 'Add Product', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
            ]),
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
              child: Column(children: [
                _card(children: [
                  _label('PRODUCT NAME'),
                  _input(_name, hint: 'e.g. Margherita Pizza'),
                  Row(children: [
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      _label('PRICE (₹)'), _input(_price, hint: '220', keyboard: TextInputType.number)])),
                    const SizedBox(width: 10),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      _label('OLD PRICE (₹)'), _input(_oldPrice, hint: '270', keyboard: TextInputType.number)])),
                  ]),
                  _label('CATEGORY'),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(border: Border.all(color: AppColors.border), borderRadius: BorderRadius.circular(12)),
                    margin: const EdgeInsets.only(bottom: 12),
                    child: DropdownButtonHideUnderline(child: DropdownButton<String>(
                      value: _category, isExpanded: true,
                      items: _categories.map((c) => DropdownMenuItem(value: c, child: Text(c, style: const TextStyle(fontSize: 13)))).toList(),
                      onChanged: (v) => setState(() => _category = v!),
                    )),
                  ),
                  _label('TYPE'),
                  Row(children: [
                    Expanded(child: _radioTile('🟢 Veg', 'veg')),
                    const SizedBox(width: 8),
                    Expanded(child: _radioTile('🔴 Non-Veg', 'nonveg')),
                  ]),
                  const SizedBox(height: 12),
                  _label('STOCK QUANTITY'),
                  _input(_stock, hint: '15', keyboard: TextInputType.number),
                  _label('IMAGE (emoji ya URL)'),
                  _input(_image, hint: '🍕'),
                  _label('DESCRIPTION'),
                  _input(_desc, hint: 'Product description...', lines: 3),
                ]),
                const SizedBox(height: 14),
                _card(children: [
                  Row(children: [
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const Text('🧀 Add-Ons / Customise', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
                      const Text('Customer ko cart mein dikhega', style: TextStyle(color: AppColors.textGrey, fontSize: 10)),
                    ])),
                  ]),
                  const SizedBox(height: 12),
                  ..._addons.asMap().entries.map((e) {
                    final i = e.key; final a = e.value;
                    return Container(
                      margin: const EdgeInsets.only(bottom: 8),
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(color: const Color(0xFFF9FAFB), borderRadius: BorderRadius.circular(10)),
                      child: Row(children: [
                        Expanded(child: TextField(controller: a['name'], decoration: const InputDecoration(hintText: 'Add-on name', border: InputBorder.none, isDense: true),
                          style: const TextStyle(fontSize: 12))),
                        SizedBox(width: 60, child: TextField(controller: a['price'], keyboardType: TextInputType.number,
                          decoration: const InputDecoration(hintText: '₹', border: InputBorder.none, isDense: true), style: const TextStyle(fontSize: 12))),
                        GestureDetector(onTap: () => _removeAddon(i), child: const Icon(Icons.close, color: AppColors.primary, size: 18)),
                      ]),
                    );
                  }),
                  GestureDetector(
                    onTap: _addAddon,
                    child: Container(
                      width: double.infinity, padding: const EdgeInsets.symmetric(vertical: 11),
                      decoration: BoxDecoration(border: Border.all(color: AppColors.primary, style: BorderStyle.solid),
                        color: const Color(0xFFFFF5F5), borderRadius: BorderRadius.circular(12)),
                      child: const Text('➕ Add New Add-On', textAlign: TextAlign.center,
                        style: TextStyle(color: AppColors.primary, fontWeight: FontWeight.w800, fontSize: 12)),
                    ),
                  ),
                ]),
                const SizedBox(height: 16),
                GestureDetector(
                  onTap: _saving ? null : _save,
                  child: Container(
                    width: double.infinity, padding: const EdgeInsets.symmetric(vertical: 16),
                    decoration: BoxDecoration(gradient: _saving ? null : AppColors.brandGradient,
                      color: _saving ? AppColors.border : null, borderRadius: BorderRadius.circular(16)),
                    child: Center(child: _saving
                      ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5))
                      : const Text('💾 Save Product', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 15))),
                  ),
                ),
              ]),
            ),
          ),
        ]),
      ),
    );
  }

  Widget _card({required List<Widget> children}) => Container(
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: children),
  );

  Widget _label(String t) => Padding(padding: const EdgeInsets.only(bottom: 4, top: 2),
    child: Text(t, style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.w800, color: AppColors.textGrey, letterSpacing: 0.3)));

  Widget _input(TextEditingController c, {String? hint, TextInputType? keyboard, int lines = 1}) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: TextField(controller: c, keyboardType: keyboard, maxLines: lines,
      decoration: InputDecoration(hintText: hint, filled: true, fillColor: const Color(0xFFF9FAFB),
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none)),
      style: const TextStyle(fontSize: 13)),
  );

  Widget _radioTile(String label, String value) {
    final selected = _type == value;
    final color = value == 'veg' ? AppColors.green : AppColors.primary;
    return GestureDetector(
      onTap: () => setState(() => _type = value),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          border: Border.all(color: selected ? color : AppColors.border, width: selected ? 1.5 : 1),
          color: selected ? color.withValues(alpha: 0.1) : Colors.white,
          borderRadius: BorderRadius.circular(12)),
        child: Text(label, textAlign: TextAlign.center, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: selected ? color : AppColors.textGrey)),
      ),
    );
  }
}
