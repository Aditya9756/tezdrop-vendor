import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../core/models/product_model.dart';
import '../../core/routes/app_routes.dart';
import '../../providers/vendor_provider.dart';

class ProductsScreen extends StatefulWidget {
  const ProductsScreen({super.key});
  @override
  State<ProductsScreen> createState() => _ProductsScreenState();
}

class _ProductsScreenState extends State<ProductsScreen> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    final vp = context.watch<VendorProvider>();
    final products = vp.products.where((p) => p.name.toLowerCase().contains(_q.toLowerCase())).toList();

    return Stack(children: [
    SafeArea(
      bottom: false,
      child: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
          child: Row(children: [
            const Text('Products', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
            const Spacer(),
            Text('${vp.products.length} items', style: const TextStyle(color: AppColors.textGrey, fontSize: 12, fontWeight: FontWeight.w600)),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.all(14),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14),
              boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 8)]),
            child: Row(children: [
              const Icon(Icons.search, color: AppColors.textLight, size: 20),
              const SizedBox(width: 8),
              Expanded(child: TextField(
                onChanged: (v) => setState(() => _q = v),
                decoration: const InputDecoration(hintText: 'Search your products...', border: InputBorder.none, isDense: true),
                style: const TextStyle(fontSize: 13),
              )),
            ]),
          ),
        ),
        Expanded(
          child: vp.loading
            ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
            : products.isEmpty
              ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Text('📦', style: TextStyle(fontSize: 48)),
                  const SizedBox(height: 8),
                  const Text('No products yet', style: TextStyle(color: AppColors.textGrey, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 4),
                  const Text('Tap + to add your first product', style: TextStyle(color: AppColors.textLight, fontSize: 12)),
                ]))
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(14, 0, 14, 90),
                  itemCount: products.length,
                  itemBuilder: (_, i) => _ProductTile(product: products[i]),
                ),
        ),
      ]),
    ),
      Positioned(
        bottom: 16, left: 0, right: 0,
        child: Center(child: GestureDetector(
          onTap: () => Navigator.pushNamed(context, AppRoutes.addProduct),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 13),
            decoration: BoxDecoration(gradient: AppColors.brandGradient, borderRadius: BorderRadius.circular(50),
              boxShadow: [BoxShadow(color: AppColors.primary.withValues(alpha: 0.4), blurRadius: 16, offset: const Offset(0, 6))]),
            child: const Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.add, color: Colors.white, size: 18),
              SizedBox(width: 6),
              Text('Add Product', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 13)),
            ]),
          ),
        )),
      ),
    ]);
  }
}

class _ProductTile extends StatelessWidget {
  final VendorProductModel product;
  const _ProductTile({required this.product});

  @override
  Widget build(BuildContext context) {
    final vp = context.read<VendorProvider>();
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 8)]),
      child: Row(children: [
        Container(width: 54, height: 54, alignment: Alignment.center,
          decoration: BoxDecoration(color: const Color(0xFFF3F4F6), borderRadius: BorderRadius.circular(12)),
          child: Text(product.image, style: const TextStyle(fontSize: 28))),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(product.name, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13), maxLines: 1, overflow: TextOverflow.ellipsis),
          Row(children: [
            Text('₹${product.price.toInt()}', style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w800, fontSize: 13)),
            if (product.oldPrice > product.price) ...[
              const SizedBox(width: 6),
              Text('₹${product.oldPrice.toInt()}', style: const TextStyle(decoration: TextDecoration.lineThrough, color: AppColors.textLight, fontSize: 10)),
            ],
          ]),
          Text('${product.category} • ${product.type == 'veg' ? '🟢 Veg' : '🔴 Non-Veg'}', style: const TextStyle(fontSize: 10, color: AppColors.textGrey)),
        ])),
        Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Switch(value: product.isActive, activeColor: AppColors.green,
            onChanged: (_) => vp.toggleProductActive(product)),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
            decoration: BoxDecoration(
              color: product.stock == 0 ? const Color(0xFFFEE2E2) : product.stock <= 5 ? const Color(0xFFFEF3C7) : const Color(0xFFDCFCE7),
              borderRadius: BorderRadius.circular(6)),
            child: Text(product.stock == 0 ? 'Out' : 'Stock: ${product.stock}',
              style: TextStyle(fontSize: 9, fontWeight: FontWeight.w700,
                color: product.stock == 0 ? AppColors.primary : product.stock <= 5 ? const Color(0xFFD97706) : const Color(0xFF16A34A))),
          ),
          const SizedBox(height: 4),
          GestureDetector(
            onTap: () => Navigator.pushNamed(context, AppRoutes.addProduct, arguments: {'product': product}),
            child: const Text('✏️ Edit', style: TextStyle(color: AppColors.primary, fontSize: 10, fontWeight: FontWeight.w800)),
          ),
        ]),
      ]),
    );
  }
}
