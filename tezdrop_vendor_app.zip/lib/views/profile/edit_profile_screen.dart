import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../core/models/vendor_model.dart';
import '../../core/services/firebase_service.dart';
import '../../providers/vendor_provider.dart';

class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({super.key});
  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  late TextEditingController _shop, _address, _open, _close;
  String _category = 'Food';
  bool _saving = false;
  final _cats = ['Food', 'Grocery', 'Pizza', 'Burger', 'Biryani', 'Beverages'];

  @override
  void initState() {
    super.initState();
    final v = context.read<VendorProvider>().vendor;
    _shop    = TextEditingController(text: v?.shopName ?? '');
    _address = TextEditingController(text: v?.address ?? '');
    _open    = TextEditingController(text: v?.openTime ?? '9:00 AM');
    _close   = TextEditingController(text: v?.closeTime ?? '11:00 PM');
    _category = v?.category ?? 'Food';
  }

  Future<void> _save() async {
    setState(() => _saving = true);
    final vp = context.read<VendorProvider>();
    final v = vp.vendor!;
    final updated = v.copyWith(
      shopName: _shop.text.trim(), address: _address.text.trim(),
      openTime: _open.text.trim(), closeTime: _close.text.trim(), category: _category,
    );
    final ok = await VendorFirebaseService.saveVendor(updated);
    setState(() => _saving = false);
    if (!mounted) return;
    if (ok) {
      await vp.loadData();
      Navigator.pop(context);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Failed to save'), behavior: SnackBarBehavior.floating));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(child: Column(children: [
        Padding(padding: const EdgeInsets.fromLTRB(16, 14, 16, 6), child: Row(children: [
          GestureDetector(onTap: () => Navigator.pop(context),
            child: Container(width: 38, height: 38, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12)),
              child: const Icon(Icons.arrow_back, size: 19))),
          const SizedBox(width: 12),
          const Text('Edit Shop Profile', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
        ])),
        Expanded(child: SingleChildScrollView(padding: const EdgeInsets.all(16), child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('SHOP NAME', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: AppColors.textGrey)),
            const SizedBox(height: 6),
            _input(_shop),
            const Text('ADDRESS', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: AppColors.textGrey)),
            const SizedBox(height: 6),
            _input(_address, lines: 2),
            const Text('CATEGORY', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: AppColors.textGrey)),
            const SizedBox(height: 6),
            Container(padding: const EdgeInsets.symmetric(horizontal: 12), margin: const EdgeInsets.only(bottom: 14),
              decoration: BoxDecoration(border: Border.all(color: AppColors.border), borderRadius: BorderRadius.circular(12)),
              child: DropdownButtonHideUnderline(child: DropdownButton<String>(value: _category, isExpanded: true,
                items: _cats.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                onChanged: (v) => setState(() => _category = v!)))),
            Row(children: [
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('OPEN TIME', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: AppColors.textGrey)),
                const SizedBox(height: 6), _input(_open)])),
              const SizedBox(width: 10),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('CLOSE TIME', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: AppColors.textGrey)),
                const SizedBox(height: 6), _input(_close)])),
            ]),
            const SizedBox(height: 8),
            GestureDetector(onTap: _saving ? null : _save, child: Container(
              width: double.infinity, padding: const EdgeInsets.symmetric(vertical: 16),
              decoration: BoxDecoration(gradient: _saving ? null : AppColors.brandGradient, color: _saving ? AppColors.border : null, borderRadius: BorderRadius.circular(14)),
              child: Center(child: _saving
                ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5))
                : const Text('Save Changes', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800))))),
          ]),
        ))),
      ])),
    );
  }

  Widget _input(TextEditingController c, {int lines = 1}) => Padding(padding: const EdgeInsets.only(bottom: 14),
    child: TextField(controller: c, maxLines: lines, decoration: InputDecoration(filled: true, fillColor: const Color(0xFFF9FAFB),
      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none)), style: const TextStyle(fontSize: 13)));
}
