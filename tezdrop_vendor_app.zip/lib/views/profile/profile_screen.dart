import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../core/routes/app_routes.dart';
import '../../providers/vendor_provider.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final vp = context.watch<VendorProvider>();
    final v = vp.vendor;

    return SafeArea(
      bottom: false,
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(0, 16, 0, 30),
        child: Column(children: [
          Container(width: 76, height: 76,
            decoration: BoxDecoration(gradient: AppColors.brandGradient, borderRadius: BorderRadius.circular(22),
              boxShadow: [BoxShadow(color: AppColors.primary.withValues(alpha: 0.3), blurRadius: 16, offset: const Offset(0, 6))]),
            child: const Center(child: Text('🍕', style: TextStyle(fontSize: 38)))),
          const SizedBox(height: 10),
          Text(v?.shopName.isNotEmpty == true ? v!.shopName : 'Your Shop', style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
          Text('${v?.phone ?? ''} • Vendor since 2026', style: const TextStyle(fontSize: 11, color: AppColors.textGrey)),

          Container(
            margin: const EdgeInsets.fromLTRB(14, 18, 14, 0),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(gradient: AppColors.brandGradient, borderRadius: BorderRadius.circular(18)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('TOTAL EARNINGS', style: TextStyle(color: Colors.white70, fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: 0.5)),
              Text('₹${vp.orders.where((o) => o.isDelivered).fold(0.0, (s, o) => s + o.total).toStringAsFixed(0)}',
                style: const TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.w900, letterSpacing: -1)),
              const SizedBox(height: 12),
              Row(children: [
                _mini('${vp.orders.length}', 'ORDERS'),
                _mini('${v?.rating.toStringAsFixed(1) ?? "0.0"}⭐', 'RATING'),
                _mini('${vp.products.length}', 'PRODUCTS'),
              ]),
            ]),
          ),

          Container(
            margin: const EdgeInsets.fromLTRB(14, 14, 14, 0),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
            child: Column(children: [
              _row(icon: '🏪', label: 'SHOP NAME', value: v?.shopName ?? '-', onTap: () => Navigator.pushNamed(context, AppRoutes.editProfile)),
              _row(icon: '📍', label: 'ADDRESS', value: v?.address.isNotEmpty == true ? v!.address : 'Not set', onTap: () => Navigator.pushNamed(context, AppRoutes.editProfile)),
              _row(icon: '⏰', label: 'TIMING', value: '${v?.openTime ?? "9 AM"} – ${v?.closeTime ?? "11 PM"}', onTap: () => Navigator.pushNamed(context, AppRoutes.editProfile)),
              _row(icon: '📞', label: 'PHONE', value: v?.phone ?? '-'),
              _row(icon: '📂', label: 'CATEGORY', value: v?.category ?? 'Food', last: true),
            ]),
          ),

          Padding(
            padding: const EdgeInsets.fromLTRB(14, 14, 14, 0),
            child: GestureDetector(
              onTap: () => _confirmLogout(context),
              child: Container(
                width: double.infinity, padding: const EdgeInsets.symmetric(vertical: 14),
                decoration: BoxDecoration(color: const Color(0xFFFEE2E2), borderRadius: BorderRadius.circular(14)),
                child: const Text('🚪 Logout', textAlign: TextAlign.center, style: TextStyle(color: AppColors.primary, fontWeight: FontWeight.w800, fontSize: 13)),
              ),
            ),
          ),
        ]),
      ),
    );
  }

  void _confirmLogout(BuildContext context) {
    showDialog(context: context, builder: (_) => AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      title: const Text('Logout?'),
      content: const Text('Are you sure you want to logout?'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        TextButton(onPressed: () {
          context.read<VendorProvider>().logout();
          Navigator.pushNamedAndRemoveUntil(context, AppRoutes.login, (r) => false);
        }, child: const Text('Logout', style: TextStyle(color: AppColors.primary))),
      ],
    ));
  }

  Widget _mini(String num, String label) => Expanded(child: Container(
    margin: const EdgeInsets.only(right: 8),
    padding: const EdgeInsets.symmetric(vertical: 8),
    decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.18), borderRadius: BorderRadius.circular(10)),
    child: Column(children: [
      Text(num, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 15)),
      Text(label, style: const TextStyle(color: Colors.white70, fontSize: 8.5, fontWeight: FontWeight.w700)),
    ]),
  ));

  Widget _row({required String icon, required String label, required String value, VoidCallback? onTap, bool last = false}) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(border: last ? null : const Border(bottom: BorderSide(color: AppColors.border))),
      child: Row(children: [
        Text(icon, style: const TextStyle(fontSize: 18)),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: const TextStyle(fontSize: 10, color: AppColors.textGrey, fontWeight: FontWeight.w700)),
          Text(value, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700)),
        ])),
        if (onTap != null) const Icon(Icons.chevron_right, color: AppColors.textLight, size: 18),
      ]),
    ),
  );
}
