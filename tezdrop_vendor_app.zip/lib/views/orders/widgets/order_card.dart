import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/models/order_model.dart';
import '../../../providers/vendor_provider.dart';

class OrderCard extends StatelessWidget {
  final VendorOrderModel order;
  const OrderCard({super.key, required this.order});

  Color get _badgeColor {
    switch (order.status) {
      case 'Pending': return AppColors.yellow;
      case 'Preparing': return AppColors.primary;
      case 'Ready': return AppColors.green;
      case 'Delivered': return AppColors.textGrey;
      case 'Cancelled': return AppColors.textLight;
      default: return AppColors.textGrey;
    }
  }

  Color get _badgeBg {
    switch (order.status) {
      case 'Pending': return const Color(0xFFFEF3C7);
      case 'Preparing': return const Color(0xFFFEE2E2);
      case 'Ready': return const Color(0xFFDCFCE7);
      default: return const Color(0xFFF3F4F6);
    }
  }

  @override
  Widget build(BuildContext context) {
    final vp = context.read<VendorProvider>();
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 10, offset: const Offset(0, 3))]),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('#${order.orderId}', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800)),
            Text('${order.customerName} • ${order.timeAgo}', style: const TextStyle(fontSize: 10, color: AppColors.textGrey)),
          ])),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(color: _badgeBg, borderRadius: BorderRadius.circular(20)),
            child: Text(order.status.toUpperCase(), style: TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: _badgeColor)),
          ),
        ]),
        const SizedBox(height: 10),
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(color: const Color(0xFFF9FAFB), borderRadius: BorderRadius.circular(10)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start,
            children: order.items.map((item) => Padding(
              padding: const EdgeInsets.only(bottom: 2),
              child: Text('${item['name'] ?? ''} × ${item['qty'] ?? 1}', style: const TextStyle(fontSize: 11, color: Color(0xFF374151))),
            )).toList()),
        ),
        const SizedBox(height: 10),
        Row(children: [
          Text('Total: ₹${order.total.toInt()}', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 14)),
          const Spacer(),
          if (order.isPending) ...[
            _SmBtn(label: '✕ Reject', bg: const Color(0xFFFEE2E2), fg: AppColors.primary,
              onTap: () => vp.updateOrderStatus(order, 'Cancelled')),
            const SizedBox(width: 6),
            _SmBtn(label: '✓ Accept', bg: AppColors.green, fg: Colors.white,
              onTap: () => vp.updateOrderStatus(order, 'Preparing')),
          ] else if (order.isPreparing)
            _SmBtn(label: 'Mark Ready', bg: AppColors.orange, fg: Colors.white,
              onTap: () => vp.updateOrderStatus(order, 'Ready')),
          if (order.isReady)
            _SmBtn(label: 'Hand to Rider', bg: AppColors.blue, fg: Colors.white,
              onTap: () => vp.updateOrderStatus(order, 'On the way')),
        ]),
      ]),
    );
  }
}

class _SmBtn extends StatelessWidget {
  final String label;
  final Color bg, fg;
  final VoidCallback onTap;
  const _SmBtn({required this.label, required this.bg, required this.fg, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(10)),
        child: Text(label, style: TextStyle(color: fg, fontSize: 11, fontWeight: FontWeight.w800)),
      ),
    );
  }
}
