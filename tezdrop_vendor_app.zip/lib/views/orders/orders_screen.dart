import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../providers/vendor_provider.dart';
import 'widgets/order_card.dart';

class OrdersScreen extends StatefulWidget {
  const OrdersScreen({super.key});
  @override
  State<OrdersScreen> createState() => _OrdersScreenState();
}

class _OrdersScreenState extends State<OrdersScreen> {
  int _tab = 0;

  @override
  Widget build(BuildContext context) {
    final vp = context.watch<VendorProvider>();
    final lists = [vp.pendingOrders, vp.preparingOrders, vp.readyOrders, vp.historyOrders];
    final labels = ['New', 'Preparing', 'Ready', 'History'];

    return SafeArea(
      bottom: false,
      child: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
          child: const Align(alignment: Alignment.centerLeft,
            child: Text('Orders', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900))),
        ),
        Padding(
          padding: const EdgeInsets.all(14),
          child: Container(
            padding: const EdgeInsets.all(4),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14),
              boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 8)]),
            child: Row(children: List.generate(4, (i) {
              final active = _tab == i;
              return Expanded(child: GestureDetector(
                onTap: () => setState(() => _tab = i),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  padding: const EdgeInsets.symmetric(vertical: 9),
                  decoration: BoxDecoration(gradient: active ? AppColors.brandGradient : null, borderRadius: BorderRadius.circular(11)),
                  child: Text(labels[i], textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: active ? Colors.white : AppColors.textGrey)),
                ),
              ));
            })),
          ),
        ),
        Expanded(
          child: vp.loading
            ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
            : lists[_tab].isEmpty
              ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Text('📭', style: TextStyle(fontSize: 48)),
                  const SizedBox(height: 8),
                  Text('No ${labels[_tab].toLowerCase()} orders', style: const TextStyle(color: AppColors.textGrey, fontWeight: FontWeight.w600)),
                ]))
              : RefreshIndicator(
                  onRefresh: vp.loadData,
                  color: AppColors.primary,
                  child: ListView.builder(
                    padding: const EdgeInsets.fromLTRB(14, 0, 14, 20),
                    itemCount: lists[_tab].length,
                    itemBuilder: (_, i) => OrderCard(order: lists[_tab][i]),
                  ),
                ),
        ),
      ]),
    );
  }
}
