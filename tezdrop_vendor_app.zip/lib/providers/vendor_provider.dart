import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import '../core/models/vendor_model.dart';
import '../core/models/product_model.dart';
import '../core/models/order_model.dart';
import '../core/services/firebase_service.dart';

class VendorProvider extends ChangeNotifier {
  SharedPreferences? _prefs;
  VendorModel? _vendor;
  List<VendorProductModel> _products = [];
  List<VendorOrderModel> _orders = [];
  bool _loading = false;
  String? _otpSession;

  VendorModel? get vendor => _vendor;
  List<VendorProductModel> get products => _products;
  List<VendorOrderModel> get orders => _orders;
  bool get loading => _loading;
  bool get isLoggedIn => _vendor != null;

  List<VendorOrderModel> get pendingOrders => _orders.where((o) => o.isPending).toList();
  List<VendorOrderModel> get preparingOrders => _orders.where((o) => o.isPreparing).toList();
  List<VendorOrderModel> get readyOrders => _orders.where((o) => o.isReady).toList();
  List<VendorOrderModel> get historyOrders => _orders.where((o) => o.isDelivered || o.isCancelled).toList();

  double get todayEarnings {
    final today = DateTime.now();
    return _orders
        .where((o) => o.isDelivered &&
            o.createdAt.day == today.day &&
            o.createdAt.month == today.month)
        .fold(0.0, (s, o) => s + o.total);
  }

  int get todayOrders {
    final today = DateTime.now();
    return _orders.where((o) =>
        o.createdAt.day == today.day &&
        o.createdAt.month == today.month).length;
  }

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    final saved = _prefs?.getString('vendor_data');
    if (saved != null) {
      try { _vendor = VendorModel.fromJson(json.decode(saved)); } catch (_) {}
    }
    notifyListeners();
  }

  void setOtpSession(String s) { _otpSession = s; }
  String? get otpSession => _otpSession;

  Future<bool> login(String phone) async {
    _loading = true;
    notifyListeners();
    final vendor = await VendorFirebaseService.getVendor(phone);
    _loading = false;
    if (vendor != null) {
      _vendor = vendor;
      _prefs?.setString('vendor_data', json.encode(vendor.toJson()));
      await loadData();
      notifyListeners();
      return true;
    }
    notifyListeners();
    return false;
  }

  Future<void> createVendor(String phone, String name, String shopName) async {
    final vendor = VendorModel(
      id: phone.replaceAll('+', '').replaceAll(' ', ''),
      phone: phone,
      name: name,
      shopName: shopName,
    );
    await VendorFirebaseService.saveVendor(vendor);
    _vendor = vendor;
    _prefs?.setString('vendor_data', json.encode(vendor.toJson()));
    await loadData();
    notifyListeners();
  }

  Future<void> loadData() async {
    if (_vendor == null) return;
    _loading = true;
    notifyListeners();
    final results = await Future.wait([
      VendorFirebaseService.getProducts(_vendor!.id),
      VendorFirebaseService.getOrders(_vendor!.id),
    ]);
    _products = results[0] as List<VendorProductModel>;
    _orders   = results[1] as List<VendorOrderModel>;
    _loading = false;
    notifyListeners();
  }

  Future<void> toggleShopOpen() async {
    if (_vendor == null) return;
    final newOpen = !_vendor!.isOpen;
    _vendor = _vendor!.copyWith(isOpen: newOpen);
    notifyListeners();
    if (_vendor!.firebaseKey.isNotEmpty) {
      await VendorFirebaseService.updateVendorOpen(_vendor!.firebaseKey, newOpen);
    }
    _prefs?.setString('vendor_data', json.encode(_vendor!.toJson()));
  }

  Future<bool> saveProduct(VendorProductModel product) async {
    final key = await VendorFirebaseService.saveProduct(product);
    if (key != null) {
      await loadData();
      return true;
    }
    return false;
  }

  Future<bool> deleteProduct(String firebaseKey) async {
    final ok = await VendorFirebaseService.deleteProduct(firebaseKey);
    if (ok) await loadData();
    return ok;
  }

  Future<bool> toggleProductActive(VendorProductModel p) async {
    final ok = await VendorFirebaseService.updateProductStock(
        p.firebaseKey, p.stock, !p.isActive);
    if (ok) await loadData();
    return ok;
  }

  Future<bool> updateOrderStatus(VendorOrderModel order, String status) async {
    final ok = await VendorFirebaseService.updateOrderStatus(
        order.phone, order.firebaseKey, status);
    if (ok) {
      final idx = _orders.indexWhere((o) => o.firebaseKey == order.firebaseKey);
      if (idx >= 0) {
        _orders[idx] = VendorOrderModel.fromJson(
          {..._orders[idx].toJson(), 'status': status},
          key: order.firebaseKey,
        );
        notifyListeners();
      }
    }
    return ok;
  }

  void logout() {
    _vendor = null;
    _products = [];
    _orders = [];
    _prefs?.remove('vendor_data');
    notifyListeners();
  }
}

extension on VendorOrderModel {
  Map<String, dynamic> toJson() => {
    'orderId'      : orderId,
    'phone'        : phone,
    'customerName' : customerName,
    'address'      : address,
    'items'        : items,
    'total'        : total,
    'status'       : status,
    'payment'      : payment,
    'createdAt'    : createdAt.toIso8601String(),
  };
}
