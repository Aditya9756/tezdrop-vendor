import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'core/constants/app_theme.dart';
import 'core/routes/app_routes.dart';
import 'providers/vendor_provider.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);

  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.dark,
    systemNavigationBarColor: Colors.white,
    systemNavigationBarIconBrightness: Brightness.dark,
  ));

  final provider = VendorProvider();
  try {
    await provider.init();
  } catch (_) {}

  runApp(ChangeNotifierProvider.value(value: provider, child: const VendorApp()));
}

class VendorApp extends StatelessWidget {
  const VendorApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'TezDrop Vendor',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      initialRoute: AppRoutes.splash,
      onGenerateRoute: AppRoutes.generate,
    );
  }
}
